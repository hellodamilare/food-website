const navMenu = document.querySelector("#nav-menu"),
menuBtn = document.querySelector("#open-menu-btn"),
closeBtn = document.querySelector("#close-menu-btn");


//  open menu

menuBtn.addEventListener('click',() => {
    navMenu.style.display = 'flex';
    closeBtn.style.display ='inline-block';
    menuBtn.style.display = 'none';
});



// close nav menu
 
closeBtn.addEventListener('click',() => {
    navMenu.style.display = 'none';
    closeBtn.style.display ='none';
    menuBtn.style.display = 'inline-block';
});


